<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMDCRM - Financeiro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/design-system.css">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 text-slate-800">

    <?php include 'nav.php'; ?>

    <main class="md:ml-64 p-4 md:p-8 pb-24 transition-all duration-300">
        <!-- Header -->
        <header class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
                <h1 class="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-slate-700 to-slate-900">
                    Financeiro & Estratégia
                </h1>
                <p class="text-slate-500 mt-1">Visão geral de fluxo de caixa e investimentos</p>
            </div>
            
            <div class="flex gap-3 items-center">
                <?php include 'header_icons.php'; ?>
                
                <!-- Global Date Filter -->
                <div class="bg-white border border-slate-200 rounded-lg p-1 flex items-center shadow-sm gap-2 px-2">
                    <select id="dateRangeSelect" class="bg-transparent text-sm font-medium text-slate-600 outline-none cursor-pointer" onchange="handleDateFilterChange()">
                        <option value="3months">Últimos 3 Meses</option>
                        <option value="current">Mês Atual</option>
                        <option value="last_month">Mês Anterior</option>
                        <option value="custom">Selecionar Mês...</option>
                    </select>
                    <input type="month" id="customMonthPicker" class="text-sm border-l pl-2 border-slate-200 text-slate-600 outline-none hidden" onchange="handleCustomDateChange()">
                </div>
                
                <button onclick="openTransactionModal()" class="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white px-5 py-2.5 rounded-lg shadow-lg shadow-emerald-500/20 font-medium flex items-center gap-2 transform hover:-translate-y-0.5 transition-all">
                    <span>+</span> Nova Transação
                </button>
            </div>
        </header>

        <!-- KPI Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Receita -->
            <div class="premium-card p-6 border-l-4 border-cyan-500 relative overflow-hidden group">
                <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <span class="text-6xl">💰</span>
                </div>
                <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Receita Estimada (MRR)</div>
                <div class="text-3xl font-bold text-slate-800 counter" id="kpiRevenue">R$ 0,00</div>
                <div class="text-xs text-emerald-600 font-medium mt-2 flex items-center gap-1">
                    <span>▲</span> Baseado em contratos ativos
                </div>
            </div>

            <!-- Despesas -->
            <div class="premium-card p-6 border-l-4 border-amber-500 relative overflow-hidden group">
                <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <span class="text-6xl">💸</span>
                </div>
                <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Despesas Totais</div>
                <div class="text-3xl font-bold text-slate-800 counter" id="kpiExpenses">R$ 0,00</div>
                <div class="text-xs text-slate-400 font-medium mt-2">
                    No período
                </div>
            </div>

            <!-- Lucro -->
            <div class="premium-card p-6 border-l-4 border-emerald-500 relative overflow-hidden group">
                <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <span class="text-6xl">📈</span>
                </div>
                <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Lucro Líquido</div>
                <div class="text-3xl font-bold text-emerald-600 counter" id="kpiProfit">R$ 0,00</div>
                <div class="text-xs text-emerald-600 font-medium mt-2 bg-emerald-50 inline-block px-1.5 py-0.5 rounded">
                    Margem: <span id="kpiMargin">0%</span>
                </div>
            </div>

            <!-- Projeção (Mock) -->
            <div class="premium-card p-6 border-l-4 border-purple-500 relative overflow-hidden group">
                <div class="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <span class="text-6xl">🔮</span>
                </div>
                <div class="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-1">Projeção Anual</div>
                <div class="text-3xl font-bold text-slate-800">R$ --</div>
                <div class="text-xs text-slate-400 font-medium mt-2">
                    Em desenvolvimento
                </div>
            </div>
        </div>

        <!-- Charts Area -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <!-- Cash Flow Chart -->
            <div class="lg:col-span-2 premium-card p-6">
                <h3 class="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <span class="w-2 h-6 bg-cyan-500 rounded-full"></span>
                    Fluxo de Caixa (6 Meses)
                </h3>
                <div class="h-64 relative">
                    <canvas id="cashFlowChart"></canvas>
                </div>
            </div>

            <!-- Expenses Breakdown -->
            <div class="premium-card p-6">
                <h3 class="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <span class="w-2 h-6 bg-amber-500 rounded-full"></span>
                    Despesas por Categoria
                </h3>
                <div class="h-64 relative flex items-center justify-center">
                    <canvas id="expensesChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Transactions Table -->
        <div class="premium-card rounded-xl overflow-hidden">
            <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 class="text-lg font-bold text-slate-800">Histórico de Transações</h3>
                <div class="flex gap-2">
                     <input type="text" placeholder="Buscar..." class="bg-white border border-slate-200 text-sm rounded-lg px-3 py-1.5 outline-none focus:border-cyan-500 transition shadow-sm">
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                    <thead class="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                        <tr>
                            <th class="p-4 w-32">Data</th>
                            <th class="p-4">Descrição</th>
                            <th class="p-4">Categoria</th>
                            <th class="p-4 text-right">Valor</th>
                            <th class="p-4 text-center">Status</th>
                            <th class="p-4 text-center w-20">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="transactionTableBody" class="divide-y divide-slate-100 text-slate-700">
                        <tr><td colspan="6" class="p-8 text-center text-slate-400">Carregando transações...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Modal Transaction -->
    <div id="transactionModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 hidden flex items-center justify-center transition-opacity opacity-0">
        <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md transform scale-95 transition-transform duration-300 p-0 overflow-hidden" id="modalContent">
            <!-- Modal Header -->
            <div class="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
                <h3 class="text-xl font-bold text-slate-800">Nova Transação</h3>
                <button onclick="closeTransactionModal()" class="text-slate-400 hover:text-slate-600 transition">✕</button>
            </div>
            
            <!-- Modal Form -->
            <form id="transactionForm" class="p-6 space-y-4">
                <input type="hidden" name="id" id="transactionId">
                
                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Descrição</label>
                    <input type="text" name="descricao" required placeholder="Ex: Pagamento Servidor" 
                        class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition font-medium text-slate-700 placeholder:text-slate-400">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Valor (R$)</label>
                        <div class="relative">
                            <span class="absolute left-3 top-2.5 text-slate-400">R$</span>
                            <input type="number" name="valor" step="0.01" required 
                                class="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition font-medium text-slate-700">
                        </div>
                    </div>
                    <div>
                         <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Data</label>
                         <input type="date" name="data_despesa" required 
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition font-medium text-slate-700">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Categoria</label>
                        <select name="categoria" class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:border-cyan-500 outline-none transition text-slate-700">
                            <option value="Marketing">Marketing</option>
                            <option value="Ferramentas">Ferramentas</option>
                            <option value="Pessoal">Pessoal</option>
                            <option value="Impostos">Impostos</option>
                            <option value="Servidor">Servidor</option>
                            <option value="Outros">Outros</option>
                        </select>
                    </div>
                    <div>
                         <input type="text" name="tipo" placeholder="Ex: Recorrente" 
                            class="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:border-cyan-500 outline-none transition text-slate-700">
                    </div>
                </div>

                <!-- Recurência -->
                <div class="bg-amber-50 p-3 rounded-lg border border-amber-100">
                    <div class="flex items-center gap-3 mb-2">
                        <input type="checkbox" id="checkRecorrente" name="recorrente" onchange="toggleRecorrencia()" class="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500 border-gray-300">
                        <label for="checkRecorrente" class="text-sm font-bold text-slate-700 select-none cursor-pointer">Despesa Recorrente?</label>
                    </div>
                    
                    <div id="divParcelas" class="hidden transition-all pl-7">
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Quantos meses repetir?</label>
                        <select name="parcelas" class="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:border-cyan-500 outline-none">
                            <option value="2">2 meses</option>
                            <option value="3">3 meses</option>
                            <option value="6">6 meses</option>
                            <option value="12" selected>12 meses (1 ano)</option>
                            <option value="24">24 meses (2 anos)</option>
                        </select>
                        <p class="text-[10px] text-slate-400 mt-1">Serão criadas transações futuras automaticamente.</p>
                    </div>
                </div>


                <!-- Footer -->
                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="closeTransactionModal()" class="px-5 py-2.5 rounded-lg text-slate-600 font-medium hover:bg-slate-100 transition">Cancelar</button>
                    <button type="submit" class="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white px-6 py-2.5 rounded-lg shadow-lg shadow-emerald-500/30 font-medium transform hover:-translate-y-0.5 transition-all">Salvar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Chart Contexts
        const ctxFlow = document.getElementById('cashFlowChart').getContext('2d');
        const ctxExpenses = document.getElementById('expensesChart').getContext('2d');
        let flowChart, expensesChart;

        // Modal Logic
        const modal = document.getElementById('transactionModal');
        const modalContent = document.getElementById('modalContent');
        const form = document.getElementById('transactionForm');

        function openTransactionModal(data = null) {
            modal.classList.remove('hidden');
            setTimeout(() => {
                modal.classList.remove('opacity-0');
                modalContent.classList.remove('scale-95');
                modalContent.classList.add('scale-100');
            }, 10);
            
            if (data) {
                // Populate Logic
            } else {
                form.reset();
                form.querySelector('[name=data_despesa]').valueAsDate = new Date();
            }
        }

        function closeTransactionModal() {
            modal.classList.add('opacity-0');
            modalContent.classList.remove('scale-100');
            modalContent.classList.add('scale-95');
            setTimeout(() => modal.classList.add('hidden'), 300);
        }

        // Handle Form Submit
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData.entries());
            
            // Handle checkbox manually if not checked (though FormData handles checked ones)
            data.recorrente = document.getElementById('checkRecorrente').checked ? 1 : 0;

            try {
                const res = await fetch('api/financeiro.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const json = await res.json();

                if (json.success) {
                    closeTransactionModal();
                    // Refresh data
                    handleDateFilterChange();
                } else {
                    alert('Erro: ' + (json.error || 'Erro desconhecido'));
                }
            } catch (err) {
                console.error(err);
                alert('Erro ao salvar transação.');
            }
        });

        // Date Filter Logic
        let currentDateRange = { start: '', end: '' };

        function handleDateFilterChange() {
            const select = document.getElementById('dateRangeSelect');
            const customPicker = document.getElementById('customMonthPicker');
            const val = select.value;
            
            if (val === 'custom') {
                customPicker.classList.remove('hidden');
                return; // Wait for user to pick date
            } else {
                customPicker.classList.add('hidden');
            }

            const today = new Date();
            let start, end;

            if (val === 'current') {
                start = new Date(today.getFullYear(), today.getMonth(), 1);
                end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            } else if (val === 'last_month') {
                start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
                end = new Date(today.getFullYear(), today.getMonth(), 0);
            } else if (val === '3months') {
                start = new Date(today.getFullYear(), today.getMonth() - 2, 1);
                end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            }

            if (val !== 'custom') {
                updateMetrics(start, end);
            }
        }

        function handleCustomDateChange() {
            const picker = document.getElementById('customMonthPicker');
            if (picker.value) {
                const [year, month] = picker.value.split('-');
                const start = new Date(year, month - 1, 1);
                const end = new Date(year, month, 0);
                updateMetrics(start, end);
            }
        }

        function updateMetrics(startDate, endDate) {
            const startStr = startDate.toISOString().split('T')[0];
            const endStr = endDate.toISOString().split('T')[0];
            loadFinancialData(startStr, endStr);
        }

        // Data Loading
        async function loadFinancialData(start = '', end = '') {
            try {
                // Default to last 3 months if not specified (for initial load)
                if (!start) {
                     const today = new Date();
                     const startDate = new Date(today.getFullYear(), today.getMonth() - 2, 1);
                     const endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                     start = startDate.toISOString().split('T')[0];
                     end = endDate.toISOString().split('T')[0];
                }

                const res = await fetch(`api/financeiro.php?start=${start}&end=${end}`);
                const data = await res.json();
                
                if (!data.success) throw new Error(data.error);

                // Update KPI Loop
                animateCounter('kpiRevenue', data.kpi.revenue);
                animateCounter('kpiExpenses', data.kpi.expenses);
                animateCounter('kpiProfit', data.kpi.profit);
                document.getElementById('kpiMargin').innerText = data.kpi.margin + '%';

                // Update Charts
                renderCharts(data.charts);
                
                // Update Table
                renderTable(data.transactions);

            } catch (err) {
                console.error(err);
            }
        }

        function animateCounter(id, target) {
            const el = document.getElementById(id);
            const duration = 1000;
            const start = 0;
            const startTime = performance.now();

            function update(time) {
                const elapsed = time - startTime;
                const progress = Math.min(elapsed / duration, 1);
                
                // Ease out quart
                const ease = 1 - Math.pow(1 - progress, 4);
                
                const current = start + (target - start) * ease;
                el.innerText = 'R$ ' + current.toLocaleString('pt-BR', {minimumFractionDigits: 2});

                if (progress < 1) requestAnimationFrame(update);
            }
            requestAnimationFrame(update);
        }

        function renderCharts(chartsData) {
            // Flow Chart
            if (flowChart) flowChart.destroy();
            flowChart = new Chart(ctxFlow, {
                type: 'bar',
                data: {
                    labels: chartsData.cash_flow.labels,
                    datasets: [
                        {
                            label: 'Receita',
                            data: chartsData.cash_flow.revenue,
                            backgroundColor: '#06b6d4',
                            borderRadius: 6,
                            barPercentage: 0.6
                        },
                        {
                            label: 'Despesas',
                            data: chartsData.cash_flow.expenses,
                            backgroundColor: '#f59e0b',
                            borderRadius: 6,
                            barPercentage: 0.6
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } },
                    scales: { 
                        y: { 
                            grid: { color: '#f1f5f9' },
                            beginAtZero: true 
                        },
                        x: { grid: { display: false } }
                    }
                }
            });

            // Expenses Doughnut
            if (expensesChart) expensesChart.destroy();
            const categories = chartsData.by_category.map(c => c.categoria);
            const values = chartsData.by_category.map(c => c.total);

            expensesChart = new Chart(ctxExpenses, {
                type: 'doughnut',
                data: {
                    labels: categories,
                    datasets: [{
                        data: values,
                        backgroundColor: ['#f59e0b', '#ef4444', '#3b82f6', '#10b981', '#6366f1'],
                        borderWidth: 0,
                        hoverOffset: 10
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: { 
                        legend: { display: false } // Custom legend could be added
                    }
                }
            });
        }

        function renderTable(transactions) {
            const tbody = document.getElementById('transactionTableBody');
            if (transactions.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="p-8 text-center text-slate-400">Nenhuma transação encontrada no período.</td></tr>';
                return;
            }

            tbody.innerHTML = transactions.map(t => `
                <tr class="group hover:bg-slate-50 transition border-b border-slate-100 last:border-0 relative">
                    <td class="p-4 font-mono text-xs text-slate-500">${new Date(t.data_despesa).toLocaleDateString()}</td>
                    <td class="p-4 font-medium text-slate-800">${t.descricao} <span class="text-xs text-slate-400 font-normal block">${t.tipo || ''}</span></td>
                    <td class="p-4">
                        <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                            ${t.categoria}
                        </span>
                    </td>
                    <td class="p-4 text-right font-bold text-slate-700">R$ ${parseFloat(t.valor).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</td>
                    <td class="p-4 text-center">
                        <span class="w-2.5 h-2.5 rounded-full ${t.status === 'pago' ? 'bg-emerald-500 shadow-lg shadow-emerald-500/30' : 'bg-amber-500'} inline-block"></span>
                    </td>
                    <td class="p-4 text-center">
                        <button onclick="deleteTransaction(${t.id})" class="text-slate-300 hover:text-rose-500 transition p-1 rounded-md hover:bg-rose-50">
                            🗑
                        </button>
                    </td>
                </tr>
            `).join('');
        }

        function toggleRecorrencia() {
            const check = document.getElementById('checkRecorrente');
            const div = document.getElementById('divParcelas');
            if(check.checked) {
                div.classList.remove('hidden');
            } else {
                div.classList.add('hidden');
            }
        }
        
        function deleteTransaction(id) {
            if(!confirm('Tem certeza que deseja excluir esta transação?')) return;

            fetch('api/financeiro.php', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id })
            })
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    // Update filters to reload data
                    handleDateFilterChange(); 
                    // Or specifically reload list if needed, but handleDateFilterChange does it
                } else {
                    alert('Erro ao excluir: ' + (data.error || 'Erro desconhecido'));
                }
            })
            .catch(err => {
                console.error('Error deleting:', err);
                alert('Erro de conexão.');
            });
        }

        // Init - trigger filters
        handleDateFilterChange();
    </script>
</body>
</html>
