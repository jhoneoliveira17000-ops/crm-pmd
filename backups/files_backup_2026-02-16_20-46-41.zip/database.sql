-- PMDCRM Database Schema
-- Updated for Recurrence and Client Fixes

CREATE DATABASE IF NOT EXISTS pmdcrm;
USE pmdcrm;

-- Tabela de Usuários (Admin)
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Clientes
CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_empresa VARCHAR(150) NOT NULL,
    nome_responsavel VARCHAR(100),
    email VARCHAR(100),
    telefone VARCHAR(20),
    segmento VARCHAR(50),
    foto_perfil LONGTEXT, -- Base64
    pasta_drive_url VARCHAR(255),
    canal_aquisicao VARCHAR(50) DEFAULT 'Indicação',
    data_entrada DATE NOT NULL,
    
    -- Dados do Contrato
    plano_nome VARCHAR(50),
    valor_mensal DECIMAL(10, 2) DEFAULT 0.00,
    periodo_meses INT DEFAULT 12,
    data_inicio_contrato DATE,
    data_fim_contrato DATE,
    status_contrato ENUM('ativo', 'inativo', 'cancelado') DEFAULT 'ativo',
    data_cancelamento DATE,
    motivo_cancelamento TEXT,
    
    -- Dados Financeiros
    dia_pagamento INT DEFAULT 5,
    metodo_pagamento VARCHAR(50),
    ultimo_pagamento DATE,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Despesas (Transações)
CREATE TABLE IF NOT EXISTS despesas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(255) NOT NULL,
    categoria VARCHAR(50), -- Marketing, Ferramentas, Pessoal, Impostos, etc.
    tipo VARCHAR(50), -- Recorrente, Único, Variável
    valor DECIMAL(10, 2) NOT NULL,
    data_despesa DATE NOT NULL,
    status ENUM('pago', 'pendente', 'atrasado', 'agendado') DEFAULT 'pago',
    recorrente BOOLEAN DEFAULT FALSE,
    id_origem_recorrencia INT, -- Para rastrear despesas criadas em lote
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
