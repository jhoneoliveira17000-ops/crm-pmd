<!-- PWA Registration -->
<link rel="manifest" href="manifest.json">
<script>
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('service-worker.js');
    }
</script>

<!-- Bottom Navbar (Mobile) -->
<nav class="fixed bottom-0 left-0 w-full bg-slate-900/90 backdrop-blur border-t border-slate-800 md:hidden z-50">
    <div class="flex justify-around items-center h-16">
        <a href="dashboard.php" class="flex flex-col items-center justify-center w-full h-full text-slate-400 hover:text-cyan-400 active:text-cyan-500 transition">
            <svg class="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
            <span class="text-[10px] uppercase font-bold tracking-wide">Dash</span>
        </a>
        <a href="clientes.php" class="flex flex-col items-center justify-center w-full h-full text-slate-400 hover:text-cyan-400 active:text-cyan-500 transition">
            <svg class="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
            <span class="text-[10px] uppercase font-bold tracking-wide">Clientes</span>
        </a>
        <div class="relative -top-5">
            <a href="clientes.php?action=new" class="bg-gradient-to-r from-cyan-500 to-blue-500 text-white w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:shadow-cyan-500/50 hover:scale-105 transition duration-300">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
            </a>
        </div>

        <a href="financeiro.php" class="flex flex-col items-center justify-center w-full h-full text-slate-400 hover:text-cyan-400 active:text-cyan-500 transition">
            <svg class="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span class="text-[10px] uppercase font-bold tracking-wide">Finan</span>
        </a>
    </div>
</nav>

<!-- Sidebar (Desktop) -->
<aside class="hidden md:flex flex-col w-64 h-screen bg-slate-900 text-white fixed top-0 left-0 border-r border-slate-800 shadow-2xl z-40">
    <div class="h-20 flex items-center justify-center border-b border-slate-800 bg-slate-900/50 backdrop-blur">
        <span class="text-2xl font-black italic tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">PMD<span class="text-white not-italic font-light">CRM</span></span>
    </div>
    
    <nav class="flex-1 px-4 py-8 space-y-2">
        <a href="dashboard.php" class="group flex items-center px-4 py-3 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-xl transition duration-200 <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'bg-gradient-to-r from-cyan-900/20 to-blue-900/20 text-cyan-400 border border-cyan-900/50 shadow-[0_0_15px_rgba(6,182,212,0.1)]' : '' ?>">
            <div class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'text-cyan-400' : 'text-slate-500 group-hover:text-cyan-400' ?> transition mr-3">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
            </div>
            <span class="font-medium tracking-wide">Dashboard</span>
        </a>
        
        <a href="clientes.php" class="group flex items-center px-4 py-3 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-xl transition duration-200 <?= basename($_SERVER['PHP_SELF']) == 'clientes.php' ? 'bg-gradient-to-r from-cyan-900/20 to-blue-900/20 text-cyan-400 border border-cyan-900/50 shadow-[0_0_15px_rgba(6,182,212,0.1)]' : '' ?>">
            <div class="<?= basename($_SERVER['PHP_SELF']) == 'clientes.php' ? 'text-cyan-400' : 'text-slate-500 group-hover:text-cyan-400' ?> transition mr-3">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
            </div>
            <span class="font-medium tracking-wide">Clientes</span>
        </a>

        <a href="financeiro.php" class="group flex items-center px-4 py-3 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-xl transition duration-200 <?= basename($_SERVER['PHP_SELF']) == 'financeiro.php' ? 'bg-gradient-to-r from-cyan-900/20 to-blue-900/20 text-cyan-400 border border-cyan-900/50 shadow-[0_0_15px_rgba(6,182,212,0.1)]' : '' ?>">
            <div class="<?= basename($_SERVER['PHP_SELF']) == 'financeiro.php' ? 'text-cyan-400' : 'text-slate-500 group-hover:text-cyan-400' ?> transition mr-3">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
            <span class="font-medium tracking-wide">Financeiro</span>
        </a>


    </nav>
    
    <div class="p-4 border-t border-slate-800 bg-slate-900/50">
        <button onclick="logout()" class="group flex items-center w-full px-4 py-2 text-rose-500 hover:text-white hover:bg-rose-600/20 rounded-lg transition duration-200">
            <svg class="w-5 h-5 mr-3 group-hover:scale-110 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
            <span class="font-medium">Sair</span>
        </button>
    </div>
</aside>

<script>
    function logout() {
        // Implementar logout simples
        window.location.href = 'index.php';
    }
</script>
