<?php
// PMDCRM/api/financeiro.php
require_once __DIR__ . '/../src/db.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/utils.php';

require_login();

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

// Utility function to get MRR for a specific period
function calculateMRR($pdo, $start, $end) {
    // Same logic as dashboard: Active contracts overlapping the period
    // Simplification: Check active contracts in that month
    $sql = "
        SELECT SUM(valor_mensal) as mrr 
        FROM clientes 
        WHERE 
            data_inicio_contrato <= ? 
            AND (data_fim_contrato IS NULL OR data_fim_contrato >= ?)
            AND (
                status_contrato = 'ativo' 
                OR (status_contrato = 'cancelado' AND data_cancelamento >= ?)
            )
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$end, $start, $start]);
    return (float)($stmt->fetch()['mrr'] ?? 0);
}

// === DELETE ===
if ($method === 'DELETE') {
    if (empty($input['id'])) {
        json_response(['success' => false, 'error' => 'ID obrigatório'], 400);
    }
    try {
        $stmt = $pdo->prepare("DELETE FROM despesas WHERE id = ?");
        $stmt->execute([(int)$input['id']]);
        json_response(['success' => true, 'message' => 'Despesa excluída com sucesso']);
    } catch (PDOException $e) {
        json_response(['success' => false, 'error' => 'Erro ao excluir: ' . $e->getMessage()], 500);
    }
    exit;
}

// === POST (CREATE or UPDATE) ===
if ($method === 'POST') {
    $id = $input['id'] ?? null;
    $descricao = sanitize_input($input['descricao'] ?? '');
    $categoria = sanitize_input($input['categoria'] ?? 'Outros');
    $tipo = sanitize_input($input['tipo'] ?? '');
    $valor = floatval($input['valor'] ?? 0);
    $data_despesa = $input['data_despesa'] ?? date('Y-m-d');
    $status = sanitize_input($input['status'] ?? 'pago');
    
    // Recurrence Logic
    $recorrente = !empty($input['recorrente']);
    $parcelas = intval($input['parcelas'] ?? 1);

    if (empty($descricao) || $valor <= 0) {
        json_response(['success' => false, 'error' => 'Descrição e Valor inválidos'], 400);
    }

    try {
        if ($id) {
            // Update single existing expense
            // IMPORTANT: Doesn't update future recurrences automatically to avoid complexity
            $stmt = $pdo->prepare("UPDATE despesas SET descricao=?, categoria=?, tipo=?, valor=?, data_despesa=?, status=? WHERE id=?");
            $stmt->execute([$descricao, $categoria, $tipo, $valor, $data_despesa, $status, $id]);
            json_response(['success' => true, 'message' => 'Despesa atualizada']);
        } else {
            // Create New
            $stmt = $pdo->prepare("INSERT INTO despesas (descricao, categoria, tipo, valor, data_despesa, status, recorrente, id_origem_recorrencia) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            
            // 1. Insert Initial
            $stmt->execute([$descricao, $categoria, $tipo, $valor, $data_despesa, $status, $recorrente ? 1 : 0, null]);
            $firstId = $pdo->lastInsertId();

            // 2. Loop for Recurrence
            if ($recorrente && $parcelas > 1) {
                // Loop starts at 1 because 0 (initial) is already inserted
                for ($i = 1; $i < $parcelas; $i++) {
                    // Calculate next date
                    $nextDate = date('Y-m-d', strtotime($data_despesa . " +$i months"));
                    // Description with installment info (optional, but helpful)
                    // $desc = "$descricao (" . ($i+1) . "/$parcelas)"; 
                    // Keeping original description for cleaner grouping
                    
                    // Future expenses start as 'agendado' or 'pendente' usually, but user might want them 'pago' immediately? 
                    // Logic: If user marks current as 'pago', future ones should probably be 'agendado' or 'pendente'.
                    // Let's default future ones to 'agendado' if current is 'pago', otherwise copy status.
                    $futureStatus = ($status === 'pago') ? 'agendado' : $status;

                    $stmt->execute([$descricao, $categoria, $tipo, $valor, $nextDate, $futureStatus, 1, $firstId]);
                }
            }

            json_response(['success' => true, 'message' => $recorrente ? "Despesa criada ($parcelas recorrências)" : 'Despesa criada', 'id' => $firstId]);
        }
    } catch (PDOException $e) {
        json_response(['success' => false, 'error' => 'Erro ao salvar: ' . $e->getMessage()], 500);
    }
    exit;
}

// === GET (LIST & METRICS) ===
if ($method === 'GET') {
    $start = $_GET['start'] ?? date('Y-m-01');
    $end = $_GET['end'] ?? date('Y-m-t');
    
    try {
        // 1. List Transactions (Despesas)
        $stmt = $pdo->prepare("
            SELECT * FROM despesas 
            WHERE data_despesa BETWEEN ? AND ? 
            ORDER BY data_despesa DESC, created_at DESC
        ");
        $stmt->execute([$start, $end]);
        $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 2. Metrics Calculation
        
        // Revenue (MRR based)
        $revenue = calculateMRR($pdo, $start, $end);
        
        // Expenses Sum
        $expenses = 0;
        foreach ($transactions as $t) {
            $expenses += (float)$t['valor'];
        }

        // Profit & Margin
        $profit = $revenue - $expenses;
        $margin = $revenue > 0 ? ($profit / $revenue) * 100 : 0;

        // 3. Charts Data

        // Expenses by Category
        $catStmt = $pdo->prepare("
            SELECT categoria, SUM(valor) as total 
            FROM despesas 
            WHERE data_despesa BETWEEN ? AND ? 
            GROUP BY categoria
        ");
        $catStmt->execute([$start, $end]);
        $expensesByCategory = $catStmt->fetchAll(PDO::FETCH_ASSOC);

        // Monthly Flow (Last 6 Months)
        $flowLabels = [];
        $flowRevenue = [];
        $flowExpenses = [];
        
        for ($i = 5; $i >= 0; $i--) {
            $mStart = date('Y-m-01', strtotime("-$i months"));
            $mEnd = date('Y-m-t', strtotime("-$i months"));
            
            $flowLabels[] = date('M', strtotime($mStart));
            
            // Rev
            $flowRevenue[] = calculateMRR($pdo, $mStart, $mEnd);
            
            // Exp
            $eStmt = $pdo->prepare("SELECT SUM(valor) as total FROM despesas WHERE data_despesa BETWEEN ? AND ?");
            $eStmt->execute([$mStart, $mEnd]);
            $flowExpenses[] = (float)($eStmt->fetch()['total'] ?? 0);
        }

        json_response([
            'success' => true,
            'transactions' => $transactions,
            'kpi' => [
                'revenue' => $revenue,
                'expenses' => $expenses,
                'profit' => $profit,
                'margin' => round($margin, 1)
            ],
            'charts' => [
                'by_category' => $expensesByCategory,
                'cash_flow' => [
                    'labels' => $flowLabels,
                    'revenue' => $flowRevenue,
                    'expenses' => $flowExpenses
                ]
            ]
        ]);

    } catch (PDOException $e) {
        json_response(['success' => false, 'error' => 'Erro ao carregar dados: ' . $e->getMessage()], 500);
    }
}
?>
