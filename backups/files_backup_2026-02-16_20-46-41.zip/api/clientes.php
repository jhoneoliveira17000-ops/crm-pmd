<?php
// PMDCRM/api/clientes.php

// Debugging
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../debug_error.txt');
error_reporting(E_ALL);

header('Content-Type: application/json');

try {
    require_once __DIR__ . '/../src/db.php';
    require_once __DIR__ . '/../src/auth.php';
    require_once __DIR__ . '/../src/utils.php';

    require_login();

    $method = $_SERVER['REQUEST_METHOD'];
    $input = json_decode(file_get_contents('php://input'), true);

    // === DELETE ===
    if ($method === 'DELETE') {
        require_login(); // Allow any logged user to delete
        
        if (empty($input['id'])) {
            json_response(['error' => 'ID obrigatório'], 400);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM clientes WHERE id = ?");
            $stmt->execute([(int)$input['id']]);
            json_response(['success' => true, 'message' => 'Cliente excluído com sucesso']);
        } catch (PDOException $e) {
            json_response(['success' => false, 'error' => 'Erro ao excluir cliente: ' . $e->getMessage()], 500);
        }
        exit;
    }

    // === POST (CREATE or UPDATE) ===
    if ($method === 'POST') {
        
        // Determine Update (has ID) or Create (no ID)
        if (!empty($input['id'])) {
            // --- UPDATE ---
            $id = (int)$input['id'];
            $campos = [];
            $valores = [];

            $permitidos = [
                'nome_empresa', 'nome_responsavel', 'email', 'telefone', 'segmento', 
                'foto_perfil', 'pasta_drive_url', 'canal_aquisicao', 'data_entrada',
                // Contrato
                'plano_nome', 'valor_mensal', 'periodo_meses', 'data_inicio_contrato', 'data_fim_contrato', 'status_contrato',
                // Pagamento
                'dia_pagamento', 'metodo_pagamento', 'ultimo_pagamento'
            ];

            foreach ($permitidos as $campo) {
                if (isset($input[$campo])) {
                    $campos[] = "$campo = ?";
                    if ($campo === 'email') {
                        $valores[] = filter_var($input[$campo], FILTER_SANITIZE_EMAIL);
                    } elseif ($campo === 'valor_mensal') {
                        $valores[] = floatval($input[$campo]);
                    } else {
                        $valores[] = sanitize_input($input[$campo]);
                    }
                }
            }

            // Recalcular data_fim se necessário
            if (isset($input['periodo_meses']) && !isset($input['data_fim_contrato'])) {
                 // Busca data_inicio atual se não foi enviada
                if (!isset($input['data_inicio_contrato'])) {
                    $stmt = $pdo->prepare("SELECT data_inicio_contrato FROM clientes WHERE id = ?");
                    $stmt->execute([$id]);
                    $current = $stmt->fetch();
                    $start = $current['data_inicio_contrato'];
                } else {
                    $start = $input['data_inicio_contrato'];
                }
                
                if ($start) {
                    $end = date('Y-m-d', strtotime($start . ' +' . intval($input['periodo_meses']) . ' months'));
                    $campos[] = "data_fim_contrato = ?";
                    $valores[] = $end;
                }
            }

            if (empty($campos)) {
                 json_response(['success' => true, 'message' => 'Nada para atualizar']);
            }

            $valores[] = $id;
            $sql = "UPDATE clientes SET " . implode(', ', $campos) . " WHERE id = ?";

            try {
                $stmt = $pdo->prepare($sql);
                $stmt->execute($valores);
                json_response(['success' => true, 'message' => 'Cliente atualizado com sucesso']);
            } catch (PDOException $e) {
                json_response(['success' => false, 'error' => 'Erro ao atualizar: ' . $e->getMessage()], 500);
            }

        } else {
            // --- CREATE ---
            // Validação básica
            if (empty($input['nome_empresa']) || empty($input['data_entrada'])) {
                json_response(['success' => false, 'error' => 'Nome da empresa e Data de Entrada são obrigatórios'], 400);
            }

            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("INSERT INTO clientes (
                    nome_empresa, nome_responsavel, email, telefone, segmento, 
                    foto_perfil, pasta_drive_url, canal_aquisicao, data_entrada,
                    plano_nome, valor_mensal, periodo_meses, 
                    data_inicio_contrato, data_fim_contrato, status_contrato,
                    dia_pagamento, metodo_pagamento,
                    instagram, landing_page_url, produto_servico
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

                $data_inicio = $input['data_inicio_contrato'] ?? $input['data_entrada'];
                $data_fim = $input['data_fim_contrato'] ?? date('Y-m-d', strtotime($data_inicio . ' +' . intval($input['periodo_meses'] ?? 12) . ' months'));

                $stmt->execute([
                    sanitize_input($input['nome_empresa']),
                    sanitize_input($input['nome_responsavel'] ?? ''),
                    filter_var($input['email'] ?? '', FILTER_SANITIZE_EMAIL),
                    sanitize_input($input['telefone'] ?? ''),
                    sanitize_input($input['segmento'] ?? ''),
                    // Foto Perfil: Ensure it's not too huge, but usually LONGTEXT handles it.
                    // Just sanitize generic input.
                    $input['foto_perfil'] ?? '', 
                    sanitize_input($input['pasta_drive_url'] ?? ''),
                    sanitize_input($input['canal_aquisicao'] ?? 'Indicação'),
                    $input['data_entrada'],
                    
                    sanitize_input($input['plano_nome'] ?? 'Padrão'),
                    floatval($input['valor_mensal'] ?? 0),
                    intval($input['periodo_meses'] ?? 12),
                    $data_inicio,
                    $data_fim,
                    in_array($input['status_contrato'] ?? 'ativo', ['ativo', 'inativo', 'cancelado']) ? $input['status_contrato'] : 'ativo',
                    
                    intval($input['dia_pagamento'] ?? 5),
                    sanitize_input($input['metodo_pagamento'] ?? 'Pix'),
                    
                    sanitize_input($input['instagram'] ?? ''),
                    sanitize_input($input['landing_page_url'] ?? ''),
                    sanitize_input($input['produto_servico'] ?? '')
                ]);

                $clienteId = $pdo->lastInsertId();
                $pdo->commit();
                json_response(['success' => true, 'message' => 'Cliente criado com sucesso', 'id' => $clienteId], 201);

            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erro ao criar cliente PDO: " . $e->getMessage()); 
                json_response(['success' => false, 'error' => 'Erro ao criar: ' . $e->getMessage()], 500);
            }
        }
        exit;
    }

    // Fallback method not allowed
    json_response(['success' => false, 'error' => 'Método inválido'], 405);

} catch (Throwable $t) {
    error_log("Erro Fatal API Clientes: " . $t->getMessage() . " in " . $t->getFile() . ":" . $t->getLine());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor: ' . $t->getMessage()]);
}
?>
