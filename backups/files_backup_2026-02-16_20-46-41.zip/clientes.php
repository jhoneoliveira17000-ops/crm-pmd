<?php
// PMDCRM/clientes.php
require_once 'src/auth.php';
require_login();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMDCRM - Clientes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .premium-card {
            background-color: #fff;
            border-radius: 1rem; /* 16px */
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            border: 1px solid #e2e8f0; /* slate-100 */
            overflow: hidden;
        }
        .input-premium {
            padding: 0.625rem 1rem; /* 10px 16px */
            border-radius: 0.625rem; /* 10px */
            border: 1px solid #e2e8f0; /* slate-200 */
            background-color: #f8fafc; /* slate-50 */
            font-size: 0.875rem; /* text-sm */
            color: #334155; /* slate-700 */
            transition: all 0.2s ease-in-out;
        }
        .input-premium:focus {
            outline: none;
            border-color: #38bdf8; /* sky-400 */
            box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.2); /* sky-400 with opacity */
            background-color: #fff;
        }
        .input-premium::placeholder {
            color: #94a3b8; /* slate-400 */
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9; /* slate-100 */
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1; /* slate-300 */
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8; /* slate-400 */
        }
    </style>
</head>
<body class="bg-slate-50 pb-20 md:pb-0 md:pl-64">

    <?php include 'nav.php'; ?>

    <main class="p-4 md:p-8">
        <header class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
                <h1 class="text-3xl font-bold text-slate-800 tracking-tight">Clientes</h1>
                <p class="text-slate-500 mt-1">Gerencie sua carteira e contratos</p>
            </div>
            <div class="flex items-center gap-2 md:gap-4">
                <?php include 'header_icons.php'; ?>

                <!-- Notification Bell -->
                <div class="relative">
                    <button id="notifBtn" class="bg-white p-2 rounded-full shadow-sm border border-slate-100 text-slate-400 hover:text-cyan-500 hover:shadow-md transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                        <span id="notifBadge" class="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full hidden shadow-sm">0</span>
                    </button>
                    <!-- Dropdown -->
                    <div id="notifDropdown" class="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-100 hidden z-50 overflow-hidden">
                        <div class="p-4 border-b border-slate-50 font-bold text-slate-700 text-sm bg-slate-50/50">Notificações</div>
                        <ul id="notifList" class="max-h-80 overflow-y-auto text-sm text-slate-600">
                            <li class="p-6 text-center text-slate-400">Nenhuma notificação</li>
                        </ul>
                    </div>
                </div>

                <button onclick="openModal('new')" class="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white px-5 py-2.5 rounded-xl font-medium shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 hover:-translate-y-0.5 transition duration-200 flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    Novo Cliente
                </button>
            </div>
        </header>

        <!-- Tabs Filter -->
        <div class="flex space-x-1 mb-6 bg-white p-1.5 rounded-xl shadow-sm border border-slate-100 w-fit">
            <button onclick="filterClients('ativo')" id="tab-ativo" class="px-5 py-2 rounded-lg text-sm font-semibold transition bg-cyan-50 text-cyan-700 shadow-sm ring-1 ring-cyan-200">Ativos</button>
            <button onclick="filterClients('inativo')" id="tab-inativo" class="px-5 py-2 rounded-lg text-sm font-medium transition text-slate-500 hover:text-slate-700 hover:bg-slate-50">Inativos</button>
        </div>

        <!-- Client List -->
        <div class="premium-card overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="text-slate-500 text-xs uppercase tracking-wider font-semibold border-b border-slate-100 bg-slate-50/50">
                            <th class="p-5">Empresa / Contrato</th>
                            <th class="p-5 hidden md:table-cell">Responsável</th>
                            <th class="p-5">Financeiro/Status</th>
                            <th class="p-5 text-right">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="clientsTableBody" class="text-slate-700 text-sm divide-y divide-slate-50">
                        <!-- JS creates rows here -->
                        <tr><td colspan="4" class="p-8 text-center text-slate-400">Carregando...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Modal Form -->
    <div id="clientModal" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm hidden flex items-center justify-center z-50 p-4 transition-opacity duration-300">
        <div class="bg-white rounded-2xl w-full max-w-2xl shadow-2xl transform transition-all scale-100 border border-slate-100" id="modalContent">
            <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 rounded-t-2xl">
                <div>
                    <h2 class="text-xl font-bold text-slate-800" id="modalTitle">Novo Cliente</h2>
                    <p class="text-xs text-slate-500 mt-0.5">Preencha os dados abaixo</p>
                </div>
                <button onclick="closeModal()" class="text-slate-400 hover:text-rose-500 transition p-2 hover:bg-rose-50 rounded-full">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
            </div>
            
            <form id="clientForm" class="p-6 space-y-6 max-h-[75vh] overflow-y-auto custom-scrollbar">
                <input type="hidden" name="id" id="clientId">
                
                <div class="flex items-center gap-6">
                    <div class="shrink-0 group relative">
                        <div class="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center border-2 border-dashed border-slate-300 group-hover:border-cyan-400 transition overflow-hidden relative">
                            <img id="previewPhoto" class="w-full h-full object-cover hidden">
                            <svg id="uploadIcon" class="w-8 h-8 text-slate-300 group-hover:text-cyan-400 transition" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        </div>
                        <input type="file" id="fotoUpload" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer">
                        <input type="hidden" name="foto_perfil" id="fotoPerfilUrl">
                        <p class="text-[10px] text-center mt-2 text-slate-500 group-hover:text-cyan-600 font-medium">Alterar Logo</p>
                    </div>

                    <div class="flex-1 space-y-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Nome da Empresa</label>
                            <input type="text" name="nome_empresa" id="nomeEmpresa" required class="input-premium w-full" placeholder="Ex: Acme Corp">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Email Principal</label>
                            <input type="email" name="email" id="email" class="input-premium w-full" placeholder="contato@empresa.com">
                        </div>
                    </div>
                </div>

                <!-- Dados Contato e Social -->
                <div class="grid grid-cols-2 gap-5">
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Responsável</label>
                        <input type="text" name="nome_responsavel" id="nomeResponsavel" class="input-premium w-full">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Telefone / WhatsApp</label>
                        <input type="text" name="telefone" id="telefone" class="input-premium w-full" placeholder="(00) 00000-0000">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-5">
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Instagram</label>
                        <div class="relative">
                            <span class="absolute left-3 top-2.5 text-slate-400 text-sm">@</span>
                            <input type="text" name="instagram" id="instagram" class="input-premium w-full pl-8" placeholder="usuario">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Landing Page / Site</label>
                         <div class="relative">
                            <span class="absolute left-3 top-2.5 text-slate-400 text-sm">🌐</span>
                            <input type="url" name="landing_page_url" id="landingPage" class="input-premium w-full pl-8" placeholder="https://...">
                        </div>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Produto / Serviço</label>
                    <textarea name="produto_servico" id="produtoServico" rows="2" class="input-premium w-full" placeholder="Descrição do produto ou serviço do cliente..."></textarea>
                </div>

                <!-- Dados do Contrato Unificados -->
                <div class="bg-slate-50 p-5 rounded-xl border border-slate-100 space-y-4 relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-blue-50 to-transparent rounded-bl-3xl -mr-2 -mt-2"></div>
                    <h3 class="text-sm font-bold text-slate-800 flex items-center gap-2 relative z-10">
                        <svg class="w-4 h-4 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        Dados do Contrato
                    </h3>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Plano</label>
                            <input type="text" name="plano_nome" id="planoNome" placeholder="Ex: Pro Mensal" class="input-premium w-full bg-white text-sm">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Valor (R$)</label>
                            <div class="relative">
                                <span class="absolute left-3 top-2.5 text-slate-400 text-sm">R$</span>
                                <input type="number" step="0.01" name="valor_mensal" id="valorMensal" placeholder="0.00" class="input-premium w-full bg-white text-sm pl-9">
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Data Início</label>
                            <input type="date" name="data_inicio_contrato" id="dataInicio" class="input-premium w-full bg-white text-sm text-slate-600">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Vigência (Meses)</label>
                            <input type="number" name="periodo_meses" id="periodoMeses" value="12" class="input-premium w-full bg-white text-sm">
                        </div>
                    </div>
                </div>

                <!-- Dados Financeiros -->
                <div class="bg-amber-50/50 p-5 rounded-xl border border-amber-100 space-y-4 relative overflow-hidden">
                    <div class="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-amber-50 to-transparent rounded-bl-3xl -mr-2 -mt-2"></div>
                    <h3 class="text-sm font-bold text-amber-800 flex items-center gap-2 relative z-10">
                        <svg class="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        Financeiro
                    </h3>
                    <div class="grid grid-cols-3 gap-4">
                        <div>
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Dia Venc.</label>
                            <input type="number" min="1" max="31" name="dia_pagamento" id="diaPagamento" value="5" class="input-premium w-full bg-white text-sm">
                        </div>
                        <div class="col-span-2">
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Método Preferido</label>
                            <select name="metodo_pagamento" id="metodoPagamento" class="input-premium w-full bg-white text-sm h-[42px]">
                                <option value="Pix">Pix (Transferência)</option>
                                <option value="Boleto">Boleto Bancário</option>
                                <option value="Cartão de Crédito">Cartão de Crédito</option>
                                <option value="Dinheiro">Dinheiro</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-5">
                     <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Canal Aquisição</label>
                        <select name="canal_aquisicao" id="canalAquisicao" class="input-premium w-full h-[42px]">
                            <option value="Indicação">Indicação</option>
                            <option value="Google Ads">Google Ads</option>
                            <option value="Meta Ads">Meta Ads</option>
                            <option value="Orgânico">Orgânico</option>
                            <option value="Outros">Outros</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Data Cadastro</label>
                        <input type="date" name="data_entrada" id="dataEntrada" required class="input-premium w-full text-slate-600">
                    </div>
                </div>
                
                 <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Pasta Drive (URL)</label>
                    <div class="relative">
                        <svg class="w-5 h-5 absolute left-3 top-2.5 text-slate-400" fill="currentColor" viewBox="0 0 24 24"><path d="M19.479 10.092l-.012-.007a3.978 3.978 0 00-.737-1.168 4.026 4.026 0 00-1.173-.733l-.007-.003-4.526-2.613-.01-.006a3.987 3.987 0 00-2.316-.562 3.97 3.97 0 00-3.197 1.42l-.006.008-3.9 6.755.004.01a3.985 3.985 0 002.046 5.378l.012.004 4.526 2.614a4.022 4.022 0 001.07.411 3.992 3.992 0 002.903-.235l.01-.006 3.9-6.755.006-.01a3.98 3.98 0 00-.593-4.5zM7.003 8.358a1.996 1.996 0 011.01-1.282l2.977-1.719-2.28 3.95H5.06l1.943-3.366zM13.68 5.64l2.923 1.688-2.26 3.914h-5.91l2.29-3.966 2.956-1.636zm2.235 12.722l-2.974 1.718-2.288-3.963 1.688-2.924 3.57 6.183.004-.014zm-4.498-2.59l-1.688-2.923 2.302-3.988h5.856l-1.936 3.355-4.534 2.618z"></path></svg>
                        <input type="url" name="pasta_drive_url" id="pastaDrive" class="input-premium w-full pl-10" placeholder="https://drive.google.com/...">
                    </div>
                </div>

                <div class="pt-6 flex justify-end gap-3 border-t border-slate-100 mt-6">
                    <button type="button" onclick="closeModal()" class="px-5 py-2.5 text-slate-500 hover:text-slate-700 hover:bg-slate-50 rounded-xl transition font-medium">Cancelar</button>
                    <button type="submit" class="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white px-8 py-2.5 rounded-xl font-semibold shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 hover:-translate-y-0.5 transition duration-200">Salvar Cliente</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let allClients = [];
        let currentFilter = 'ativo';

        async function loadClients() {
            const tbody = document.getElementById('clientsTableBody');
            tbody.innerHTML = '<tr><td colspan="4" class="p-8 text-center"><div class="animate-pulse flex justify-center"><div class="h-2 w-24 bg-slate-200 rounded"></div></div></td></tr>';
            
            try {
                const res = await fetch('api/list_clientes.php');
                allClients = await res.json();
                if(!Array.isArray(allClients)) throw new Error("Formato inválido da API");
                renderClients();
            } catch (err) {
                console.error("Erro ao carregar clientes:", err);
                tbody.innerHTML = '<tr><td colspan="4" class="p-8 text-center text-rose-500">Erro ao carregar dados. Verifique o console.</td></tr>';
            }
        }

        function filterClients(status) {
            currentFilter = status;
            
            // Update UI Tabs
            document.getElementById('tab-ativo').className = status === 'ativo' 
                ? 'px-5 py-2 rounded-lg text-sm font-semibold transition bg-cyan-50 text-cyan-700 shadow-sm ring-1 ring-cyan-200 transform scale-105' 
                : 'px-5 py-2 rounded-lg text-sm font-medium transition text-slate-500 hover:text-slate-700 hover:bg-slate-50';
            
            document.getElementById('tab-inativo').className = status === 'inativo' 
                ? 'px-5 py-2 rounded-lg text-sm font-semibold transition bg-white text-cyan-700 shadow-sm ring-1 ring-cyan-200 transform scale-105' 
                : 'px-5 py-2 rounded-lg text-sm font-medium transition text-slate-500 hover:text-slate-700 hover:bg-slate-50';

            renderClients();
        }

        function renderClients() {
            const tbody = document.getElementById('clientsTableBody');
            const filtered = allClients.filter(c => {
                if (currentFilter === 'ativo') return c.status_contrato === 'ativo';
                return c.status_contrato !== 'ativo';
            });

            if (filtered.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="p-12 text-center text-slate-400 flex flex-col items-center"><svg class="w-12 h-12 mb-3 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"></path></svg>Nenhum cliente encontrado nesta aba.</td></tr>';
                return;
            }

            tbody.innerHTML = filtered.map(c => {
                // Logic for remaining time
                let durationHtml = '';
                if (c.status_contrato === 'ativo' && c.data_fim_contrato) {
                    const today = new Date();
                    const end = new Date(c.data_fim_contrato);
                    const diffTime = end - today;
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    let colorClass = 'text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded text-[10px] font-bold';
                    let text = `${diffDays} dias`;
                    
                    if (diffDays < 0) {
                        colorClass = 'text-rose-600 bg-rose-50 px-2 py-0.5 rounded text-[10px] font-bold';
                        text = 'Vencido';
                    } else if (diffDays <= 30) {
                        colorClass = 'text-amber-600 bg-amber-50 px-2 py-0.5 rounded text-[10px] font-bold';
                    }
                    durationHtml = `<span class="${colorClass}">${text}</span>`;
                }

                // Payment Status Logic (Simple Mock for now)
                let paymentStatusHtml = '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">Em dia</span>';
                
                // Real logic would be: if (today > c.data_pagamento && !c.ultimo_pagamento) ...

                const photoUrl = c.foto_perfil ? c.foto_perfil : `https://ui-avatars.com/api/?name=${encodeURIComponent(c.nome_empresa)}&background=random`;

                return `
                <tr class="border-b border-slate-50 last:border-0 hover:bg-slate-50 transition">
                    <td class="p-4 flex items-center space-x-3">
                        <img src="${photoUrl}" class="w-10 h-10 rounded-full object-cover bg-slate-100">
                        <div>
                            <div class="font-medium text-slate-900">${c.nome_empresa}</div>
                            <div class="text-xs text-slate-500">${c.plano_nome || 'Sem plano'} - R$ ${parseFloat(c.valor_mensal || 0).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</div>
                            ${durationHtml}
                        </div>
                    </td>
                    <td class="p-4 hidden md:table-cell">${c.nome_responsavel || '-'}</td>
                    <td class="p-4">
                        <span class="px-2 py-1 ${c.status_contrato === 'ativo' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'} rounded-full text-xs capitalize">${c.status_contrato || 'ativo'}</span>
                    </td>
                    <td class="p-4">
                        <div class="flex flex-col">
                            ${paymentStatusHtml}
                            <span class="text-xs text-slate-500 mt-1">${c.metodo_pagamento || 'Pix'}</span>
                        </div>
                    </td>
                    <td class="p-4 text-center">
                        <div class="flex items-center justify-center gap-2">
                             <a href="cliente_dashboard.php?id=${c.id}" class="text-blue-500 hover:text-blue-700 p-1.5 hover:bg-blue-50 rounded-lg transition" title="Abrir Pasta">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z"></path></svg>
                            </a>
                            <button onclick="triggerEditClient(${c.id})" class="text-slate-400 hover:text-cyan-600 transition p-1.5 hover:bg-cyan-50 rounded-lg" title="Editar">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                            </button>
                            <button onclick="toggleClientStatus(${c.id}, '${c.status_contrato}')" class="text-slate-400 hover:text-amber-500 transition p-1.5 hover:bg-amber-50 rounded-lg" title="${c.status_contrato === 'ativo' ? 'Desativar' : 'Ativar'}">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path></svg>
                            </button>
                             <button onclick="deleteClient(${c.id})" class="text-slate-400 hover:text-rose-500 transition p-1.5 hover:bg-rose-50 rounded-lg" title="Excluir">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </div>
                    </td>
                </tr>
            `}).join('');
        }

        // Modal Logic
        const modal = document.getElementById('clientModal');
        const form = document.getElementById('clientForm');

        function toggleClientStatus(id, currentStatus) {
            const newStatus = currentStatus === 'ativo' ? 'inativo' : 'ativo';
            const action = newStatus === 'ativo' ? 'ativar' : 'desativar';
            
            if(!confirm(`Deseja realmente ${action} este cliente?`)) return;

            fetch('api/clientes.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id, status_contrato: newStatus })
            })
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    loadClients();
                    alert(`Cliente ${newStatus === 'ativo' ? 'ativado' : 'desativado'} com sucesso!`);
                } else {
                    alert('Erro ao atualizar status: ' + (data.error || 'Erro desconhecido'));
                }
            })
            .catch(err => {
                console.error('Error toggling status:', err);
                alert('Erro de conexão.');
            });
        }

        function triggerEditClient(id) {
            const client = allClients.find(c => c.id == id);
            if(client) editClient(client);
        }

        function openModal(mode, data = null) {
            modal.classList.remove('hidden');
            document.getElementById('previewPhoto').classList.add('hidden');
            if (mode === 'new') {
                document.getElementById('modalTitle').innerText = 'Novo Cliente';
                form.reset();
                document.getElementById('clientId').value = '';
                document.getElementById('clientId').value = '';
                document.getElementById('dataEntrada').valueAsDate = new Date();
                document.getElementById('dataInicio').valueAsDate = new Date();
                
                // Ensure default status is active for new clients
                if(!document.querySelector('input[name="status_contrato"]')) {
                    const statusInput = document.createElement('input');
                    statusInput.type = 'hidden';
                    statusInput.name = 'status_contrato';
                    statusInput.value = 'ativo';
                    form.appendChild(statusInput);
                } else {
                    document.querySelector('input[name="status_contrato"]').value = 'ativo';
                }
            }
        }

        function editClient(data) {
            modal.classList.remove('hidden');
            document.getElementById('modalTitle').innerText = 'Editar Cliente';
            document.getElementById('clientId').value = data.id;
            document.getElementById('nomeEmpresa').value = data.nome_empresa;
            document.getElementById('nomeResponsavel').value = data.nome_responsavel;
            document.getElementById('email').value = data.email;
            document.getElementById('telefone').value = data.telefone;
            document.getElementById('instagram').value = data.instagram || '';
            document.getElementById('landingPage').value = data.landing_page_url || '';
            document.getElementById('produtoServico').value = data.produto_servico || '';
            document.getElementById('canalAquisicao').value = data.canal_aquisicao;
            document.getElementById('dataEntrada').value = data.data_entrada;
            document.getElementById('pastaDrive').value = data.pasta_drive_url;
            
            // Novos campos
            document.getElementById('planoNome').value = data.plano_nome;
            document.getElementById('valorMensal').value = data.valor_mensal;
            document.getElementById('dataInicio').value = data.data_inicio_contrato;
            document.getElementById('periodoMeses').value = data.periodo_meses;
            document.getElementById('fotoPerfilUrl').value = data.foto_perfil;
            
            // Novos campos Financeiros
            document.getElementById('diaPagamento').value = data.dia_pagamento || 5;
            document.getElementById('metodoPagamento').value = data.metodo_pagamento || 'Pix';
            document.getElementById('ultimoPagamento').value = data.ultimo_pagamento || '';
            
            if(data.foto_perfil) {
                document.getElementById('previewPhoto').src = data.foto_perfil;
                document.getElementById('previewPhoto').classList.remove('hidden');
                document.getElementById('uploadIcon').classList.add('hidden');
            } else {
                document.getElementById('previewPhoto').classList.add('hidden');
                document.getElementById('uploadIcon').classList.remove('hidden');
            }
        }

        function closeModal() {
            modal.classList.add('hidden');
        }

        // Close on click outside
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });

        // Form Submit
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(form);
            
            // Convert FormData to JSON object for API
            const plainFormData = Object.fromEntries(formData.entries());
            
            // Se for edição, o ID já está no form
            // Se for novo, ID é vazio

            try {
                const res = await fetch('api/clientes.php', {
                    method: 'POST', // Using POST for both create and update (internal logic handles it)
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(plainFormData)
                });

                const result = await res.json();
                if (result.success) {
                    closeModal();
                    loadClients();
                    // Show success toast (mock)
                    alert('Cliente salvo com sucesso!');
                } else {
                    alert('Erro: ' + (result.error || 'Falha ao salvar'));
                }
            } catch (err) {
                console.error(err);
                alert('Erro de conexão.');
            }
        });

        async function deleteClient(id) {
            if(!confirm('Tem certeza que deseja excluir este cliente?')) return;

            try {
                const res = await fetch('api/clientes.php', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                
                if (res.ok) {
                    loadClients();
                } else {
                    alert('Erro ao excluir.');
                }
            } catch (err) {
                console.error(err);
            }
        }

        // Photo Upload Handling
        const uploadInput = document.getElementById('fotoUpload');
        if(uploadInput) {
            uploadInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
            if(file) {
                const reader = new FileReader();
                reader.onloadend = function() {
                    document.getElementById('previewPhoto').src = reader.result;
                    document.getElementById('previewPhoto').classList.remove('hidden');
                    document.getElementById('uploadIcon').classList.add('hidden');
                    document.getElementById('fotoPerfilUrl').value = reader.result; // Save Base64 to hidden input
                }
                reader.readAsDataURL(file);
            }
        });
        }

        // Initial Load
        loadClients();

        // Notifications Logic
        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');
        const notifBadge = document.getElementById('notifBadge');
        const notifList = document.getElementById('notifList');

        notifBtn.addEventListener('click', () => {
            notifDropdown.classList.toggle('hidden');
        });

        async function checkNotifications() {
            try {
                const res = await fetch('api/notifications.php');
                const data = await res.json();
                
                if (data.length > 0) {
                    notifBadge.innerText = data.length;
                    notifBadge.classList.remove('hidden');
                    notifBtn.classList.replace('text-slate-400', 'text-slate-600');
                    
                    notifList.innerHTML = data.map(n => {
                            // Contract expiration logic
                            let icon = '📄';
                            let urgencyText = `Contrato vence em ${n.dias_restantes} dias`;
                            let colorClass = 'text-slate-500';

                            if (n.dias_restantes < 0) {
                                urgencyText = `Vencido há ${Math.abs(n.dias_restantes)} dias`;
                                colorClass = 'text-rose-600 font-bold';
                            } else if (n.dias_restantes <= 7) {
                                colorClass = 'text-amber-600 font-bold';
                            }
                        
                        return `
                        <li class="p-3 border-b border-slate-50 last:border-0 hover:bg-slate-50 cursor-pointer">
                            <div class="flex items-start gap-2">
                                <span class="text-lg">${icon}</span>
                                <div class="flex-1">
                                    <div class="font-medium text-slate-800">${n.nome_empresa}</div>
                                    <div class="text-xs ${colorClass}">${urgencyText}</div>
                                </div>
                            </div>
                        </li>
                    `}).join('');
                } else {
                    notifBadge.classList.add('hidden');
                    notifList.innerHTML = '<li class="p-4 text-center text-slate-400">Nenhuma notificação</li>';
                }
            } catch (err) {
                console.error(err);
            }
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!notifBtn.contains(e.target) && !notifDropdown.contains(e.target)) {
                notifDropdown.classList.add('hidden');
            }
        });

        checkNotifications();

        // Check for ?action=new to open modal automatically
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('action') === 'new') {
            // Remove params from URL so it doesn't reopen on refresh
            window.history.replaceState({}, document.title, window.location.pathname);
            openModal('new');
        }
    </script>
</body>
</html>
