<?php
// PMDCRM/dashboard.php
require_once 'src/auth.php';
require_login();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PMDCRM - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="assets/css/design-system.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .counter { animation: countUp 0.6s cubic-bezier(0.34, 1.56, 0.64, 1); }
        /* Custom Scrollbar for Notifications */
        #notifList::-webkit-scrollbar { width: 6px; }
        #notifList::-webkit-scrollbar-track { bg: #f1f5f9; }
        #notifList::-webkit-scrollbar-thumb { bg: #cbd5e1; border-radius: 3px; }
    </style>
</head>
<body class="bg-slate-50 pb-20 md:pb-0 md:pl-64">

    <?php include 'nav.php'; ?>

    <main class="p-4 md:p-8">
        <!-- Header Section -->
        <header class="gradient-header -mx-4 md:-mx-8 -mt-4 md:-mt-8 px-4 md:px-8 py-6 mb-8 shadow-lg relative z-20">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-white tracking-tight">Dashboard</h1>
                    <p class="text-slate-100/80 text-sm mt-1">Visão geral e métricas em tempo real</p>
                </div>
                
                <div class="flex items-center gap-3">
                    <!-- Global Date Filter -->
                    <div class="flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-2 rounded-lg border border-white/20 shadow-sm">
                        <svg class="w-4 h-4 text-white/80" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        
                        <select id="dateRangeSelect" class="bg-transparent text-white text-sm font-medium outline-none cursor-pointer hover:text-cyan-100 transition [&>option]:text-slate-700" onchange="handleDateFilterChange()">
                            <option value="3months">Últimos 3 Meses</option>
                            <option value="current">Mês Atual</option>
                            <option value="last_month">Mês Anterior</option>
                            <option value="custom">Selecionar Mês...</option>
                        </select>
                        
                        <input type="month" id="customMonthPicker" class="text-sm bg-white/20 text-white border-0 rounded px-2 py-0.5 outline-none hidden placeholder-white" onchange="handleCustomDateChange()">
                    </div>

                    <!-- Icons -->
                    <?php include 'header_icons.php'; ?>

                    <!-- Notification Bell -->
                    <div class="relative">
                        <button id="notifBtn" class="bg-white/10 p-2.5 rounded-lg text-white hover:bg-white/20 hover:shadow-lg transition relative border border-white/10">
                            <span class="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-transparent hidden shadow-sm" id="notifBadge"></span>
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                        </button>
                        
                        <!-- Dropdown Notificacoes -->
                        <div id="notifDropdown" class="hidden absolute right-0 top-14 w-80 bg-white rounded-xl shadow-2xl border border-slate-100 z-50 overflow-hidden ring-1 ring-black/5">
                            <div class="px-4 py-3 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
                                <span class="font-bold text-slate-700 text-sm">Notificações</span>
                                <span class="text-xs text-slate-400">Recentes</span>
                            </div>
                            <ul id="notifList" class="max-h-80 overflow-y-auto">
                                <li class="p-6 text-center text-slate-400 text-sm italic">Nenhuma notificação nova</li>
                            </ul>
                        </div>
                    </div>
                    
                    <a href="clientes.php?action=new" class="hidden md:flex items-center gap-2 bg-white text-cyan-600 px-4 py-2 rounded-lg font-bold text-sm shadow-md hover:shadow-xl hover:bg-cyan-50 transition transform hover:-translate-y-0.5">
                        <span>+</span> Novo Cliente
                    </a>
                </div>
            </div>
        </header>

        <!-- Metric Cards Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- 1. Faturamento (MRR) -->
            <div class="premium-card p-6 border-l-4 border-cyan-500 relative overflow-hidden group hover-lift">
                <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">💰</span>
                </div>
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Faturamento (MRR)</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-slate-800 counter" id="metric-mrr">R$ 0,00</span>
                </div>
                <div class="text-xs text-emerald-600 font-medium inline-flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full">
                    <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                    Receita Recorrente
                </div>
            </div>

            <!-- 2. Custos -->
            <div class="premium-card p-6 border-l-4 border-amber-500 relative overflow-hidden group hover-lift">
                 <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">💸</span>
                </div>
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Custos Totais</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-slate-800 counter" id="metric-cac">R$ 0,00</span>
                </div>
                 <div class="text-xs text-slate-400 font-medium mt-1">
                    Investimentos e Despesas
                </div>
            </div>

            <!-- 3. Lucro -->
            <div class="premium-card p-6 border-l-4 border-emerald-500 relative overflow-hidden group hover-lift">
                 <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">📈</span>
                </div>
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Lucro Líquido</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-emerald-600 counter" id="metric-lucro">R$ 0,00</span>
                </div>
                 <div class="text-xs text-emerald-600 font-medium inline-flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full">
                    Saldável
                </div>
            </div>

             <!-- 4. LTV -->
            <div class="premium-card p-6 border-l-4 border-violet-500 relative overflow-hidden group hover-lift">
                 <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">⚡</span>
                </div>
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">LTV Estimado</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-slate-800 counter" id="metric-ltv">R$ 0,00</span>
                </div>
                 <div class="text-xs text-slate-400 font-medium mt-1">
                    Lifetime Value
                </div>
            </div>

            <!-- 5. Churn -->
            <div class="premium-card p-6 border-l-4 border-rose-500 relative overflow-hidden group hover-lift">
                 <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">📉</span>
                </div>
               <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Churn Rate</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-slate-800 counter" id="metric-churn">0%</span>
                </div>
                 <div class="text-xs text-rose-500 font-medium mt-1">
                    Taxa de cancelamento
                </div>
            </div>

            <!-- 6. Ativos -->
             <div class="premium-card p-6 border-l-4 border-cyan-500 relative overflow-hidden group hover-lift">
                 <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">👥</span>
                </div>
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Clientes Ativos</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-slate-800 counter" id="metric-ativos">0</span>
                </div>
                 <div class="text-xs text-slate-400 font-medium mt-1">
                    Base atual
                </div>
            </div>

             <!-- 7. Ticket Medio -->
             <div class="premium-card p-6 border-l-4 border-emerald-500 relative overflow-hidden group hover-lift">
                 <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">🎫</span>
                </div>
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Ticket Médio</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-slate-800 counter" id="metric-ticket">R$ 0,00</span>
                </div>
                 <div class="text-xs text-slate-400 font-medium mt-1">
                    Por cliente ativo
                </div>
            </div>

            <!-- 8. Novos -->
             <div class="premium-card p-6 border-l-4 border-emerald-500 relative overflow-hidden group hover-lift">
                 <div class="absolute top-0 right-0 p-4 opacity-[0.03] group-hover:opacity-10 transition-opacity">
                    <span class="text-7xl">✨</span>
                </div>
                <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Novos este Mês</div>
                <div class="flex items-center gap-1 mb-1">
                    <span class="text-3xl font-bold text-emerald-600 counter" id="metric-novos">0</span>
                </div>
                 <div class="text-xs text-emerald-600 font-medium mt-1">
                    Crescimento recente
                </div>
            </div>
        </div>

        <!-- Charts Grid 2x2 -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- 1. Financial Evolution -->
            <div class="premium-card p-6">
                <h3 class="text-base font-bold text-slate-700 mb-6 flex items-center gap-2 border-b border-slate-50 pb-4">
                    <span class="w-1.5 h-1.5 bg-cyan-500 rounded-full"></span>
                    Evolução Financeira
                </h3>
                <div class="h-64 w-full relative">
                    <canvas id="financeChart"></canvas>
                </div>
            </div>

            <!-- 2. Client Growth -->
            <div class="premium-card p-6">
                <h3 class="text-base font-bold text-slate-700 mb-6 flex items-center gap-2 border-b border-slate-50 pb-4">
                    <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                    Crescimento de Clientes
                </h3>
                <div class="h-64 w-full relative">
                    <canvas id="growthChart"></canvas>
                </div>
            </div>

            <!-- 3. Payment Methods -->
            <div class="premium-card p-6">
                <h3 class="text-base font-bold text-slate-700 mb-6 flex items-center gap-2 border-b border-slate-50 pb-4">
                    <span class="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
                    Métodos de Pagamento
                </h3>
                <div class="h-64 w-full relative flex items-center justify-center">
                    <canvas id="methodsChart"></canvas>
                </div>
            </div>

            <!-- 4. Top Clients -->
            <div class="premium-card p-6">
                <h3 class="text-base font-bold text-slate-700 mb-6 flex items-center gap-2 border-b border-slate-50 pb-4">
                    <span class="w-1.5 h-1.5 bg-rose-500 rounded-full"></span>
                    Top 5 Clientes (MRR)
                </h3>
                <div class="h-64 w-full relative">
                    <canvas id="topClientsChart"></canvas>
                </div>
            </div>
        </div>

    </main>

    <script>
        // --- 1. CONFIGURAÇÃO DOS GRÁFICOS ---
        const ctxFinance = document.getElementById('financeChart').getContext('2d');
        const ctxGrowth = document.getElementById('growthChart').getContext('2d');
        const ctxMethods = document.getElementById('methodsChart').getContext('2d');
        const ctxTopClients = document.getElementById('topClientsChart').getContext('2d');
        
        let financeChart, growthChart, methodsChart, topClientsChart;

        function renderCharts(data) {
            // Gradient Setup
            const gradientMrr = ctxFinance.createLinearGradient(0, 0, 0, 300);
            gradientMrr.addColorStop(0, 'rgba(6, 182, 212, 0.4)'); // Cyan
            gradientMrr.addColorStop(1, 'rgba(6, 182, 212, 0.0)');

            const gradientProfit = ctxFinance.createLinearGradient(0, 0, 0, 300);
            gradientProfit.addColorStop(0, 'rgba(16, 185, 129, 0.4)'); // Emerald
            gradientProfit.addColorStop(1, 'rgba(16, 185, 129, 0.0)');

            // 1. Finance (Line/Bar Sync)
            if (financeChart) financeChart.destroy();
            financeChart = new Chart(ctxFinance, {
                type: 'line',
                data: {
                    labels: data.history.labels,
                    datasets: [
                        { label: 'MRR', data: data.history.mrr, borderColor: '#06b6d4', backgroundColor: gradientMrr, fill: true, tension: 0.4, borderWidth: 2, pointRadius: 3 },
                        { label: 'Lucro', data: data.history.lucro, borderColor: '#10b981', backgroundColor: gradientProfit, fill: true, tension: 0.4, borderWidth: 2, pointRadius: 3 },
                        { label: 'Custos', data: data.history.custos, type: 'bar', backgroundColor: '#f59e0b', borderRadius: 4, barPercentage: 0.4 }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: 'index', intersect: false },
                    plugins: { 
                        legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 6, font: { size: 11 } } },
                        tooltip: { backgroundColor: '#1e293b', padding: 10, cornerRadius: 8 }
                    },
                    scales: {
                        y: { beginAtZero: true, grid: { borderDash: [2, 4], color: '#f1f5f9' }, ticks: { font: { size: 10 } } },
                        x: { grid: { display: false }, ticks: { font: { size: 10 } } }
                    }
                }
            });

            // 2. Growth (Bar Stacked-ish)
            if (growthChart) growthChart.destroy();
            growthChart = new Chart(ctxGrowth, {
                type: 'bar',
                data: {
                     labels: data.history.labels,
                     datasets: [
                         { label: 'Novos', data: data.history.novos, backgroundColor: '#10b981', borderRadius: 4, barPercentage: 0.6 },
                         { label: 'Cancelados', data: data.history.cancelados, backgroundColor: '#f43f5e', borderRadius: 4, barPercentage: 0.6 }
                     ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 6 } } },
                    scales: {
                        y: { beginAtZero: true, grid: { borderDash: [2, 4], color: '#f1f5f9' }, ticks: { stepSize: 1 } },
                        x: { grid: { display: false } }
                    }
                }
            });

            // 3. Methods (Doughnut)
            if (methodsChart) methodsChart.destroy();
            const methodColors = ['#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#f43f5e'];
            methodsChart = new Chart(ctxMethods, {
                type: 'doughnut',
                data: {
                    labels: data.metodos_pagamento.map(m => m.metodo_pagamento || 'N/A'),
                    datasets: [{
                        data: data.metodos_pagamento.map(m => m.qtd),
                        backgroundColor: methodColors,
                        borderWidth: 2,
                        borderColor: '#ffffff'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '75%',
                    plugins: { legend: { position: 'right', labels: { usePointStyle: true, boxWidth: 8, font: { size: 11 } } } }
                }
            });

            // 4. Top Clients (Horizontal Bar)
            if (topClientsChart) topClientsChart.destroy();
            topClientsChart = new Chart(ctxTopClients, {
                type: 'bar',
                indexAxis: 'y',
                data: {
                    labels: data.top_clientes.map(c => c.nome_empresa),
                    datasets: [{
                        label: 'MRR',
                        data: data.top_clientes.map(c => c.valor_mensal),
                        backgroundColor: '#f43f5e', // Use Rose for Top Clients accent
                        borderRadius: 4,
                        barPercentage: 0.5
                    }]
                },
                 options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    indexAxis: 'y',
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { beginAtZero: true, grid: { borderDash: [2, 4], color: '#f1f5f9' } },
                        y: { grid: { display: false } }
                    }
                }
            });
        }

        // --- 2. LÓGICA DE DADOS E FILTROS ---
        
        function handleDateFilterChange() {
            const select = document.getElementById('dateRangeSelect');
            const customPicker = document.getElementById('customMonthPicker');
            const val = select.value;
            
            if (val === 'custom') {
                customPicker.classList.remove('hidden');
                // Don't auto-update yet, wait for month selection
            } else {
                customPicker.classList.add('hidden');
                // Calculate dates
                const today = new Date();
                let start, end;
                
                if (val === 'current') {
                    // Mês Atual: 1º dia até último dia
                    start = new Date(today.getFullYear(), today.getMonth(), 1);
                    end = new Date(today.getFullYear(), today.getMonth() + 1, 0); 
                } else if (val === 'last_month') {
                    // Mês Anterior
                    start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
                    end = new Date(today.getFullYear(), today.getMonth(), 0);
                } else {
                    // 3 Messrs (Padrão)
                    start = new Date(today.getFullYear(), today.getMonth() - 2, 1); // -2 months + current = 3 months span roughly
                    end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                }
                updateMetrics(start, end);
            }
        }

        function handleCustomDateChange() {
            const picker = document.getElementById('customMonthPicker');
            if (picker.value) {
                const [year, month] = picker.value.split('-');
                const start = new Date(year, month - 1, 1);
                const end = new Date(year, month, 0);
                updateMetrics(start, end);
            }
        }

        function updateMetrics(startDate, endDate) {
            // Format YYYY-MM-DD
            const startStr = startDate.toLocaleDateString('en-CA'); // ISO format trick
            const endStr = endDate.toLocaleDateString('en-CA');
            loadMetrics(startStr, endStr);
        }

        async function loadMetrics(start = '', end = '') {
            try {
                // Initial load default
                if (!start) {
                     const today = new Date();
                     const s = new Date(today.getFullYear(), today.getMonth() - 2, 1);
                     const e = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                     start = s.toLocaleDateString('en-CA');
                     end = e.toLocaleDateString('en-CA');
                }

                const res = await fetch(`api/metricas_dashboard.php?inicio=${start}&fim=${end}`);
                const data = await res.json();
                
                // Counters
                animateCounter('metric-mrr', data.mrr, true);
                animateCounter('metric-cac', data.cac, true);
                animateCounter('metric-lucro', data.lucro, true);
                animateCounter('metric-ltv', data.ltv, true);
                
                document.getElementById('metric-churn').innerText = (data.churn_rate || 0).toFixed(1) + '%';
                document.getElementById('metric-ativos').innerText = data.clientes_ativos || 0;
                animateCounter('metric-ticket', data.ticket_medio, true);
                document.getElementById('metric-novos').innerText = data.novos_mes_atual || 0;
                
                // Charts
                renderCharts(data);

            } catch (err) {
                console.error('Erro ao carregar métricas:', err);
            }
        }

        function animateCounter(id, target, isCurrency = false) {
             const el = document.getElementById(id);
             // Simple formatting for now
             if(isCurrency) {
                 el.innerText = 'R$ ' + parseFloat(target || 0).toLocaleString('pt-BR', {minimumFractionDigits: 2});
             } else {
                 el.innerText = target;
             }
        }

        // --- 3. NOTIFICAÇÕES (Dropdown) ---
        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');
        const notifBadge = document.getElementById('notifBadge');
        const notifList = document.getElementById('notifList');

        notifBtn.addEventListener('click', (e) => {
             e.stopPropagation();
             notifDropdown.classList.toggle('hidden');
             if(!notifDropdown.classList.contains('hidden')){
                 loadNotifications();
             }
        });

        document.addEventListener('click', (e) => {
            if (!notifBtn.contains(e.target) && !notifDropdown.contains(e.target)) {
                notifDropdown.classList.add('hidden');
            }
        });

        async function loadNotifications() {
            try {
                // Mock notification endpoint or real one
                const res = await fetch('api/notifications.php'); 
                if(!res.ok) throw new Error('No notification API');
                const data = await res.json();
                
                if (data.length > 0) {
                    notifBadge.innerText = data.length;
                    notifBadge.classList.remove('hidden');
                    notifList.innerHTML = data.map(n => `
                        <li class="p-3 border-b border-slate-50 last:border-0 hover:bg-slate-50 cursor-pointer transition">
                            <div class="flex items-start gap-3">
                                <span class="text-xl bg-slate-100 p-1 rounded-md">📢</span>
                                <div>
                                    <div class="font-bold text-slate-700 text-sm">${n.nome_empresa || 'Sistema'}</div>
                                    <div class="text-xs text-slate-500">${n.mensagem || 'Nova notificação'}</div>
                                </div>
                            </div>
                        </li>
                    `).join('');
                } else {
                    notifBadge.classList.add('hidden');
                    notifList.innerHTML = '<li class="p-6 text-center text-slate-400 text-sm italic">Nenhuma notificação nova</li>';
                }
            } catch(e) {
                // Silent fail or mock
                console.log('Notifications skipped');
            }
        }

        // Init
        handleDateFilterChange(); // Triggers loadMetrics with default range

    </script>
</body>
</html>
